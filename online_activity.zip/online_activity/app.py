from flask import Flask, render_template, request, redirect, jsonify
from sqlite3 import connect, Row

app = Flask(__name__)

def get_connection():
    conn = connect('db/school.db')
    conn.row_factory = Row
    return conn

@app.route('/')
def index():
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM students")
    students = cursor.fetchall()
    conn.close()
    return render_template('index.html', studentlist=students)  # FIXED name to match HTML

@app.route('/save', methods=['POST'])
def save_student():
    id = request.form.get('id', '')
    idno = request.form.get('idno', '')
    lastname = request.form.get('lastname', '')
    firstname = request.form.get('firstname', '')
    course = request.form.get('course', '')
    level = request.form.get('level', '')

    conn = get_connection()
    cursor = conn.cursor()

    if id:  
        cursor.execute("""
            UPDATE students 
            SET idno=?, lastname=?, firstname=?, course=?, level=?
            WHERE id=?
        """, (idno, lastname, firstname, course, level, id))
    else:  
        cursor.execute("""
            INSERT INTO students (idno, lastname, firstname, course, level)
            VALUES (?, ?, ?, ?, ?)
        """, (idno, lastname, firstname, course, level))

    conn.commit()
    conn.close()
    return redirect('/')

@app.route('/delete/<int:id>', methods=['POST'])
def delete_student(id):
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("DELETE FROM students WHERE id=?", (id,))
    conn.commit()
    conn.close()
    return jsonify({'success': True})

if __name__ == '__main__':
    app.run(debug=True)
